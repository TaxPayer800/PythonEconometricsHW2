#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import statsmodels.formula.api as smf


# In[2]:


df = pd.read_csv("xid-10049253_1.csv", header=0, sep=';')


# In[3]:


df['r2e'] = df['r2'] - df['rf']
df = df[['date', 'mktrf','r1', 'r2', 'r2e']]
df[['r1','r2', 'r2e']]=df[['r1','r2', 'r2e']].round(2)
df.head()


# In[4]:


reg1 = smf.ols('r1 ~ 1', data=df).fit()
print('alpha r1', reg1.params[0].round(2))
print('alpha se r1', reg1.bse[0].round(2))


# In[5]:


reg2 = smf.ols('r2e ~ mktrf', data=df).fit()
print('alpha r2', reg2.params[0].round(2))
print('beta r2', reg2.params[1].round(2))
print('alpha se r2', reg2.bse[0].round(2))
print('beta se r2', reg2.bse[1].round(2))


# In[6]:


reg1.summary()


# In[7]:


reg2.summary()


# In[8]:


print('thank you ;)')




